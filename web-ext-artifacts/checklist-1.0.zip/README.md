# Checklist App

Hosted on [Netlify](https://darling-cactus-8382d1.netlify.app/)

Built using vanilla Javascript, HTML, and CSS
